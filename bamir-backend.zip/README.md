# BAMİR Online Store’s — Backend

Kurulum
```
npm install
npm run start
```

Canlıya Alma
- **Railway/Render/Heroku**: `server.js` çalışır.
- **Vercel**: `api/index.js` kullanılır. `vercel.json` hazır.

Endpoint'ler
- `GET /` sağlık kontrolü
- `GET /api/products` ürün listesi
- `POST /api/order` sipariş

Tarih: 2025-12-15T15:54:52
