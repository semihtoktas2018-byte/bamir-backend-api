// BAMİR Online Store’s
// Express backend – Railway/Render/Heroku için hazır

const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ ok: true, brand: "BAMİR Online Store’s", ts: new Date().toISOString() });
});

app.get("/api/products", (req, res) => {
  res.json([{ id: 1, name: "BAMİR Premium Product", price: 199, stock: 50, brand: "BAMİR Online Store’s" }]);
});

app.post("/api/order", (req, res) => {
  const { productId, quantity } = req.body || {};
  res.json({ ok: true, message: "Order received", order: { productId, quantity, time: Date.now(), brand: "BAMİR Online Store’s" } });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`BAMİR Online Store’s backend listening on ${PORT}`);
});
